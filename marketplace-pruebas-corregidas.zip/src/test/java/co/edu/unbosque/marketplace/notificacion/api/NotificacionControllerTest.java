package co.edu.unbosque.marketplace.notificacion.api;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import co.edu.unbosque.marketplace.notificacion.application.NotificacionConsultaService;
import co.edu.unbosque.marketplace.publicacion.application.port.CacheBusquedaPublicaciones;

@WebMvcTest(NotificacionController.class)
class NotificacionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private NotificacionConsultaService consultaService;

    @MockitoBean
    private CacheBusquedaPublicaciones cacheBusquedaPublicaciones;

    private UUID idUsuario;

    @BeforeEach
    void setUp() {
        idUsuario = UUID.randomUUID();
    }

    @Test
    void consultarMisNotificacionesSinAutenticacion() throws Exception {
        mockMvc.perform(get("/notificaciones/mis-notificaciones"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.mensaje").value(
                        "Debes iniciar sesión para consultar tus notificaciones."
                ));

        verifyNoInteractions(consultaService);
    }

    @Test
    void consultarMisNotificacionesCorrectamente() throws Exception {
        when(consultaService.consultarMisNotificaciones(idUsuario))
                .thenReturn(List.of());

        mockMvc.perform(
                get("/notificaciones/mis-notificaciones")
                        .with(user(new UsuarioPrincipalPrueba(idUsuario)))
        )
                .andExpect(status().isOk())
                .andExpect(content().json("[]"));

        verify(consultaService).consultarMisNotificaciones(idUsuario);
    }

    private static final class UsuarioPrincipalPrueba implements UserDetails {

        private final UUID idUsuario;

        private UsuarioPrincipalPrueba(UUID idUsuario) {
            this.idUsuario = idUsuario;
        }

        public UUID getIdUsuario() {
            return idUsuario;
        }

        @Override
        public Collection<? extends GrantedAuthority> getAuthorities() {
            return List.of(new SimpleGrantedAuthority("ROLE_HUESPED"));
        }

        @Override
        public String getPassword() {
            return "";
        }

        @Override
        public String getUsername() {
            return "huesped-prueba";
        }

        @Override
        public boolean isAccountNonExpired() {
            return true;
        }

        @Override
        public boolean isAccountNonLocked() {
            return true;
        }

        @Override
        public boolean isCredentialsNonExpired() {
            return true;
        }

        @Override
        public boolean isEnabled() {
            return true;
        }
    }
}
